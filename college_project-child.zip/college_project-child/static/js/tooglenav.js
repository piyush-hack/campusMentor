$("#toogle_nav").click(function () {
  $(".alloptions").toggle(1000);
});
